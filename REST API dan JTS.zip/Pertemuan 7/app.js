const express = require("express");
const bodyParser = require("body-parser"); 
const koneksi = require("./config/database"); 

const app = express(); 

const PORT = process.env.PORT || 5000; 

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//create//
app.post("/api/latihanrestapi", (req, res) => {
    const data = req.body;

    const querySql = "INSERT INTO latihanrestapi SET ?";

    koneksi.query(querySql, data, (err, rows) => {
        if (err) {
            return res.status(500).json({
                message: "Gagal insert data!",
                error: err.message, 
            });
        }

        return res.status(200).json({
            message: "Behasil insert data!",
            data: rows, 
        });
    });
});

//read//
app.get('/api/latihanrestapi', (req, res) => {
    
    const querySql = 'SELECT * FROM latihanrestapi';

    koneksi.query(querySql, (err, rows, fields) => {
        
        if (err) {
            return res.status(500).json({
                message: 'Ada kesalahan, silahkan coba lagi',
                error: err
            });
        }

        res.status(200).json({
            success: true,
            data: rows
        });
    });
});

//update//
app.put('/api/latihanrestapi/:id', (req, res) => {

    const data = { ...req.body };
    const querySearch = 'SELECT * FROM latihanrestapi WHERE id = ?';
    const queryUpdate = 'UPDATE latihanrestapi SET ? WHERE id = ?';

    koneksi.query(querySearch, [req.params.id], (err, rows) => {
       
        if (err) {
            return res.status(500).json({
                message: 'Ada kesalahan saat mencari data',
                error: err
            });
        }

        if (rows.length) {

            koneksi.query(queryUpdate, [data, req.params.id], (err, result) => {
                
                if (err) {
                    return res.status(500).json({
                        message: 'Ada kesalahan',
                        error: err
                    });
                }

                res.status(200).json({
                    success: true,
                    message: 'Berhasil update data!',
                    affectedRows: result.affectedRows
                });
            });
        } else {

            return res.status(404).json({
                message: 'Data tidak ditemukan!',
                success: false
            });
        }
    });
});


//delete//
app.delete('/api/latihanrestapi/:id', (req, res) => {
   
    const querySearch = 'SELECT * FROM latihanrestapi WHERE id = ?';
    const queryDelete = 'DELETE FROM latihanrestapi WHERE id = ?';

    koneksi.query(querySearch, [req.params.id], (err, rows) => {

        if (err) {
            return res.status(500).json({
                message: 'Ada kesalahan',
                error: err
            });
        }

        if (rows.length) {
            
            koneksi.query(queryDelete, [req.params.id], (err, result) => {

                if (err) {
                    return res.status(500).json({
                        message: 'Ada kesalahan',
                        error: err
                    });
                }

                res.status(200).json({
                    success: true,
                    message: 'Berhasil hapus data!',
                    affectedRows: result.affectedRows
                });
            });
        } else {
         
            return res.status(404).json({
                message: 'Data tidak ditemukan!',
                success: false
            });
        }
    });
});

app.listen(PORT, () => {
    console.log(`Server running at port: ${PORT}`); 
})




   

   