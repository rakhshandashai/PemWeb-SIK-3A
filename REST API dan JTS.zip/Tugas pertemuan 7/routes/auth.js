const express = require('express');
const bcrypt = require('bcryptjs');
const { generateToken, revokeToken } = require('../utils/tokenManager');

const router = express.Router();
const users = []; // Simulated user database

// Register a new user
router.post('/register', async (req, res) => {
    const { username, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    users.push({ username, password: hashedPassword });
    res.status(201).json({ message: 'User registered successfully' });
});

// Login and get token
router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = users.find((u) => u.username === username);

    if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).json({ message: 'Invalid credentials' });
    }

    const token = generateToken({ username });
    res.status(200).json({ token });
});

// Revoke a token
router.post('/revoke', (req, res) => {
    const { token } = req.body;
    revokeToken(token);
    res.status(200).json({ message: 'Token revoked successfully' });
});

module.exports = router;
