const express = require('express');
const authMiddleware = require('../middleware/authMiddleware');
const loggingMiddleware = require('../middleware/loggingMiddleware');

const router = express.Router();

// Data endpoint with authentication and logging
router.get('/', authMiddleware, loggingMiddleware, (req, res) => {
    res.status(200).json({ message: 'Here is your secured data', user: req.user });
});

module.exports = router;
